import React, { Component } from 'react';

class Hello extends Component
{
    render()
    {
        return <div> Hallo test 123 {this.props.Name} </div>;
    }
}

export default Hello;
